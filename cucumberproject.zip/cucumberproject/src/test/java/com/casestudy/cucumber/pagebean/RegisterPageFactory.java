package com.casestudy.cucumber.pagebean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class RegisterPageFactory {  // DO NOT CHANGE THE CLASS NAME

	// Use the below declared variable 
	public WebDriver driver;
    public static String childWinTitle; // store page title of child window
    
    //Constructors are already given. 
    //If required, you can add more code into it but do NOT remove the existing code.
    public RegisterPageFactory(){}
    
	public RegisterPageFactory(WebDriver driver){
		this.driver= driver;
		PageFactory.initElements(driver, this);
	}
	
	// Use @FindBy annotation to identify and locate the web elements

    @FindBy(xpath="/html/body/div/div/div/div/div/div[5]/a")
    public WebElement registerHereElmt;
            
    @FindBy(xpath="/html/body/div/div/div/div/div[1]/div[1]/input")
    public WebElement usernameRegElmt;
                        
    @FindBy(xpath="/html/body/div/div/div/div/div[1]/div[2]/input")
    public WebElement passwordRegElmt;
                                        
    @FindBy(xpath="/html/body/div/div/div/div/div[1]/div[3]/input")
    public WebElement emailRegElmt;

    @FindBy(xpath="/html/body/div/div/div/div/div[1]/div[4]/input")
    public WebElement submitbtnRegElmt;

    @FindBy(xpath="/html/body/div/div/div/div/div[2]/h3")
    public WebElement registrationMsgElmt;  

    @FindBy(xpath="/html/body/div/div/div/div/div[1]/div[1]/div")
    public WebElement usernameErrRegElmt;   

    @FindBy(xpath="/html/body/div/div/div/div/div[1]/div[2]/div")
    public WebElement passwordErrRegElmt;

    @FindBy(xpath="/html/body/div/div/div/div/div[1]/div[3]/div")
    public WebElement emailErrRegElmt;

    public void clickRegistrationForm() {       
        registerHereElmt.click();
    }

    public void setRegUsername(String uname) {
        usernameRegElmt.sendKeys(uname);
    }

    public void setRegPassword(String passwd) {
        passwordRegElmt.sendKeys(passwd);
    }

    public void setRegEmail(String email) {
        emailRegElmt.sendKeys(email);
    }

    public void clickRegLoginBtn() {        
        submitbtnRegElmt.click();
    }

    public String getRegistrationMsg() {        
        return registrationMsgElmt.getText();
    }

    public String getRegUsernameError() {       
        return usernameErrRegElmt.getText();
    }
    public String getRegPasswordError() {       
        return passwordErrRegElmt.getText();
    }
  
    public String getRegEmailError() {      
        return emailErrRegElmt.getText();
    }
 
    public String getChildWindow() {         
        String MainWindow = driver.getWindowHandle();
                      
        Set<String> s1 = driver.getWindowHandles();
        Iterator<String> i1 = s1.iterator();
                                               
        while (i1.hasNext()) {
            String ChildWindow = i1.next();
            if (!MainWindow.equalsIgnoreCase(ChildWindow)) {
                driver.switchTo().window(ChildWindow);
                childWinTitle=driver.getTitle();
            }
        }
        return childWinTitle;
    }


    
    
}
